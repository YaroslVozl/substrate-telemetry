declare module '*.svg'
declare module '*.png'
declare module '*.jpg'
