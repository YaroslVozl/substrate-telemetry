declare module '*.svg';
